<div align="center">

<img src="https://raw.githubusercontent.com/Clairvoyance/Clairvoyance/output/snake.svg" alt="banner" width="100%">

# Hi there, I'm Uttkarsh Rai <img src="https://raw.githubusercontent.com/ABSphreak/ABSphreak/master/wave.gif" width="30px">

</div>

<div align="center">

<img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=22&pause=1000&color=2E9EF7&center=true&vCenter=true&width=600&lines=B.Tech+Final+Year+%7C+Computer+Science+and+Engineering;Aspiring+Data+Analyst+%7C+Python+%26+SQL+Learner;Building+Real-World+Dashboards+and+Data+Projects" alt="Typing SVG" />

</div>

<div align="center">

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://linkedin.com/in/your-linkedin-here)
[![Portfolio](https://img.shields.io/badge/Portfolio-000000?style=for-the-badge&logo=vercel&logoColor=white)](https://your-portfolio-here.com)
[![Email](https://img.shields.io/badge/Email-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:uttkarshraiskr_cse22@its.edu.in)
![Profile Views](https://komarev.com/ghpvc/?username=Clairvoyance&style=for-the-badge&color=blue)

</div>

---

## 🚀 About Me

I'm a final-year Computer Science student who enjoys turning raw data into clear, usable insights. I'm currently sharpening my skills in Python, SQL, and data visualization by building real-world dashboards and mini data-analysis projects.

- 🔍 Passionate about data analysis, dashboards, and finding patterns in messy datasets
- 🐍 Comfortable working across the Python data stack (pandas, NumPy)
- 📊 Interested in turning raw data into decision-ready visuals

🎓 **Education:** B.Tech, Computer Science and Engineering — ITS Engineering College (Final Year)

⚙️ **Current Interests:**
- Data Analysis & Visualization (Python, SQL, Power BI)
- Building interactive dashboards
- Data cleaning & EDA (Exploratory Data Analysis)
- Exploring Machine Learning fundamentals

🤝 **Open to:** Data Analyst internships, entry-level Data/ML roles, and collaborating on open-source data projects. Feel free to reach out!

---

## 🧠 Tech Stack

**Languages:** Python • SQL • C++ • JavaScript

**Data & Analysis:** Pandas • NumPy • Power BI • Excel • Jupyter Notebook

**Tools & Platforms:** Git • GitHub • VS Code • MySQL • Google Colab

---

## 🔥 Featured Projects

### 📈 Sales Dashboard Analytics
A dashboard that visualizes sales trends, regional performance, and product-level KPIs from raw CSV data. Built with **Python**, **Pandas**, and **Power BI** for interactive drill-down reporting.

🔗 [View Repository](https://github.com/Clairvoyance/sales-dashboard-analytics)

### 🧹 Data Cleaning & EDA Toolkit
A reusable set of scripts for cleaning messy datasets and generating quick exploratory summaries — missing-value handling, outlier detection, and auto-generated charts. Built with **Python**, **Pandas**, and **Matplotlib**.

🔗 [View Repository](https://github.com/Clairvoyance/data-cleaning-eda-toolkit)

> ✏️ *Replace the project names, descriptions, and links above with your actual repos.*

---

## 📊 GitHub Stats

<div align="center">

<img height="165" src="https://github-readme-stats.vercel.app/api?username=Clairvoyance&show_icons=true&theme=dark&hide_border=true" />
<img height="165" src="https://github-readme-streak-stats.herokuapp.com/?user=Clairvoyance&theme=dark&hide_border=true" />

</div>

---

## 📫 Connect With Me

<div align="center">

[LinkedIn](https://linkedin.com/in/your-linkedin-here) • [Portfolio](https://your-portfolio-here.com) • [Email](mailto:uttkarshraiskr_cse22@its.edu.in)

</div>

---

<div align="center">

### ✨ "Turning data into decisions, one dashboard at a time." ✨

<img src="https://raw.githubusercontent.com/platane/snk/output/github-contribution-grid-snake.svg" alt="snake animation" />

</div>
